-- Total Sales Records
SELECT COUNT(*) AS total_sales
FROM sales;

-- Total Customers
SELECT COUNT(DISTINCT CustomerKey) AS total_customers
FROM customers;

-- Total Products
SELECT COUNT(DISTINCT ProductKey) AS total_products
FROM products;

-- Total Stores
SELECT COUNT(DISTINCT StoreKey) AS total_stores
FROM stores;

-- Fetch sales data with customer and product details
SELECT
    s.OrderNumber,
    s.OrderDate,
    c.Name AS CustomerName,
    p.ProductName,
    s.Quantity
FROM sales s
JOIN customers c
ON s.CustomerKey = c.CustomerKey
JOIN products p
ON s.ProductKey = p.ProductKey
LIMIT 10;

-- Revenue Analysis

SELECT
    p.ProductName,
    s.Quantity,
    p.UnitPriceUSD,
    (s.Quantity * p.UnitPriceUSD) AS Revenue
FROM sales s
JOIN products p
ON s.ProductKey = p.ProductKey
LIMIT 10;

-- Top Selling Products
SELECT
    p.ProductName,
    SUM(s.Quantity) AS TotalQuantitySold
FROM sales s
JOIN products p
ON s.ProductKey = p.ProductKey
GROUP BY p.ProductName
ORDER BY TotalQuantitySold DESC
LIMIT 10;

-- Total Revenue by Product
SELECT
    p.ProductName,
    ROUND(SUM(s.Quantity * p.UnitPriceUSD), 2) AS TotalRevenue
FROM sales s
JOIN products p
ON s.ProductKey = p.ProductKey
GROUP BY p.ProductName
ORDER BY TotalRevenue DESC
LIMIT 10;

-- Revenue by Country
SELECT
    c.Country,
    ROUND(SUM(s.Quantity * p.UnitPriceUSD), 2) AS Revenue
FROM sales s
JOIN customers c
ON s.CustomerKey = c.CustomerKey
JOIN products p
ON s.ProductKey = p.ProductKey
GROUP BY c.Country
ORDER BY Revenue DESC;

-- Monthly Revenue Trend
SELECT
    YEAR(s.OrderDate) AS Year,
    MONTH(s.OrderDate) AS Month,
    ROUND(SUM(s.Quantity * p.UnitPriceUSD), 2) AS Revenue
FROM sales s
JOIN products p
ON s.ProductKey = p.ProductKey
GROUP BY YEAR(s.OrderDate), MONTH(s.OrderDate)
ORDER BY Year, Month;

-- Top Customers by Revenue
SELECT
    c.Name,
    ROUND(SUM(s.Quantity * p.UnitPriceUSD), 2) AS TotalSpent
FROM sales s
JOIN customers c
ON s.CustomerKey = c.CustomerKey
JOIN products p
ON s.ProductKey = p.ProductKey
GROUP BY c.Name
ORDER BY TotalSpent DESC
LIMIT 10;

-- Best Performing Stores
SELECT
    st.Country,
    st.State,
    ROUND(SUM(s.Quantity * p.UnitPriceUSD), 2) AS StoreRevenue
FROM sales s
JOIN stores st
ON s.StoreKey = st.StoreKey
JOIN products p
ON s.ProductKey = p.ProductKey
GROUP BY st.Country, st.State
ORDER BY StoreRevenue DESC
LIMIT 10;

-- Most Sold Product Categories
SELECT
    p.Category,
    SUM(s.Quantity) AS QuantitySold
FROM sales s
JOIN products p
ON s.ProductKey = p.ProductKey
GROUP BY p.Category
ORDER BY QuantitySold DESC;

-- Average Order Value
SELECT
    ROUND(AVG(order_total), 2) AS AverageOrderValue
FROM
(
    SELECT
        OrderNumber,
        SUM(s.Quantity * p.UnitPriceUSD) AS order_total
    FROM sales s
    JOIN products p
    ON s.ProductKey = p.ProductKey
    GROUP BY OrderNumber
) t;

-- Repeat Customers

SELECT
    c.Name,
    COUNT(DISTINCT s.OrderNumber) AS TotalOrders
FROM sales s
JOIN customers c
ON s.CustomerKey = c.CustomerKey
GROUP BY c.Name
HAVING COUNT(DISTINCT s.OrderNumber) > 1
ORDER BY TotalOrders DESC
LIMIT 10;

-- Highest Revenue Generating Product Category
SELECT
    p.Category,
    ROUND(SUM(s.Quantity * p.UnitPriceUSD), 2) AS Revenue
FROM sales s
JOIN products p
ON s.ProductKey = p.ProductKey
GROUP BY p.Category
ORDER BY Revenue DESC;

-- KPI QUERIES FOR DASHBOARD

-- Total Revenue
SELECT ROUND(SUM(s.Quantity * p.UnitPriceUSD),2) AS TotalRevenue
FROM sales s
JOIN products p
ON s.ProductKey = p.ProductKey;

-- Total Orders
SELECT COUNT(DISTINCT OrderNumber) AS TotalOrders
FROM sales;

-- Total Quantity Sold
SELECT SUM(Quantity) AS TotalQuantitySold
FROM sales;

-- Unique Customers
SELECT COUNT(DISTINCT CustomerKey) AS UniqueCustomers
FROM sales;